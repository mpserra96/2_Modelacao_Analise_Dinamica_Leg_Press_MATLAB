% --------------------------------------------------------------
% ANIMAÇÃO - LEG PRESS (sem guia) - joelho nunca "dá a volta"
% Desenho por PONTOS (anca->joelho->tornozelo), não por ângulos
% --------------------------------------------------------------
vel = 0.1;

xmin = -0.5; xmax = 2.0;
ymin = -0.2; ymax = 2.6;

hw = 1000;

C1 = 'y';   % coxa
C2 = 'b';   % perna
C3 = 'm';   % carrinho/plataforma
CJ = 'k';   % juntas

dxw = xmax-xmin; dyw = ymax-ymin;
if dxw > dyw, px=hw; py=dyw/dxw*hw; else, py=hw; px=dxw/dyw*hw; end

figure('Position',[50,50,px,py]);
ax = gca;
axis(ax,[xmin xmax ymin ymax]);
axis(ax,'equal');
grid(ax,'on');
drawnow;

tanim = 0; flag = false;
tic
while ~flag

    i = round(tanim/h) + 1;
    if i < 1, i = 1; end
    if i > length(T), i = length(T); end

    % estados
    x1 = Y(1,i);  y1 = Y(2,i);  th1 = Y(3,i);
    x2 = Y(4,i);  y2 = Y(5,i);  th2 = Y(6,i);
    x3 = Y(7,i);  y3 = Y(8,i);  th3 = Y(9,i);

    % se a simulação colapsou, pára
    if any(~isfinite([x1 y1 th1 x2 y2 th2 x3 y3 th3]))
        warning('A simulação gerou NaN/Inf por volta de t = %.4f s. A animação foi interrompida.', T(i));
        break
    end

    % ----------------------------------------------------------
    % PONTOS FÍSICOS (coerentes com as tuas restrições Φ)
    % ----------------------------------------------------------

    % ANCA fixa (no chão): ponto do elo 1 a -0.433*l1 do COM
    H = [ x1 - 0.433*l1*cos(th1);
          y1 - 0.433*l1*sin(th1) ];

    % JOELHO: ponto do elo 1 a +0.567*l1 do COM (ponto "real")
    K = [ x1 + 0.567*l1*cos(th1);
          y1 + 0.567*l1*sin(th1) ];

    % TORNOZELO (no elo 2): ponto do elo 2 a +0.394*l2 do COM
    A = [ x2 + 0.394*l2*cos(th2);
          y2 + 0.394*l2*sin(th2) ];

    % (opcional) ponto correspondente no carrinho (deve coincidir)
    A3 = [ x3 - 0.5*l3*cos(th3);
           y3 - 0.5*l3*sin(th3) ];

    % ----------------------------------------------------------
    % DESENHO (por pontos, sem risco de flip do joelho)
    % ----------------------------------------------------------
    cla(ax); hold(ax,'on');

    % coxa: anca -> joelho
    plot(ax, [H(1) K(1)], [H(2) K(2)], 'Color',C1,'LineWidth',3);

    % perna: joelho -> tornozelo  (isto impede o "dar a volta")
    plot(ax, [K(1) A(1)], [K(2) A(2)], 'Color',C2,'LineWidth',3);

    % carrinho/plataforma: desenha como barra centrada no COM (podes manter)
    E3a = [x3-(l3/2)*cos(th3); y3-(l3/2)*sin(th3)];
    E3b = [x3+(l3/2)*cos(th3); y3+(l3/2)*sin(th3)];
    plot(ax, [E3a(1) E3b(1)], [E3a(2) E3b(2)], 'Color',C3,'LineWidth',4);

    % juntas
    plot(ax, H(1),H(2),'o','Color',CJ,'MarkerFaceColor',CJ,'MarkerSize',7);
    plot(ax, K(1),K(2),'o','Color',CJ,'MarkerFaceColor',CJ,'MarkerSize',7);
    plot(ax, A(1),A(2),'o','Color',CJ,'MarkerFaceColor',CJ,'MarkerSize',7);

    % validação (se quiseres): ponto do carrinho
    plot(ax, A3(1),A3(2),'x','Color',CJ,'MarkerSize',9,'LineWidth',1.5);

    % tempo
    tstr = sprintf('t = %1.3f s', T(i));
    text(ax, xmin+0.05*(xmax-xmin), ymin+0.07*(ymax-ymin), tstr, ...
        'FontSize',14,'Color','k');

    grid(ax,'on');
    axis(ax,[xmin xmax ymin ymax]);
    axis(ax,'equal');
    drawnow;

    tanim = vel * toc;
    if tanim > tfinal || i == length(T)
        flag = true;
    end
end
