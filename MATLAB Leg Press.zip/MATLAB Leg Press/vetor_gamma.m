   % -------------------------
    % GAMMA
    % -------------------------
    w1 = y(12);  w2 = y(15);  w3 = y(18);

    rhs_a1 = -0.433*l1*cos(y(3)) * w1^2;
    rhs_a2 = -0.433*l1*sin(y(3)) * w1^2;

    rhs_a3 =  0.567*l1*cos(y(3)) * w1^2 + (0.606*l2)*cos(y(6)) * w2^2;
    rhs_a4 =  0.567*l1*sin(y(3)) * w1^2 + (0.606*l2)*sin(y(6)) * w2^2;

    rhs_a5 = (0.394*l2)*cos(y(6)) * w2^2 + 0.5*l3*cos(y(9)) * w3^2;
    rhs_a6 = (0.394*l2)*sin(y(6)) * w2^2 + 0.5*l3*sin(y(9)) * w3^2;

    rhs_a7 = 0;
    rhs_a8 = 0;

    gamma = [rhs_a1; rhs_a2; rhs_a3; rhs_a4; rhs_a5; rhs_a6; rhs_a7; rhs_a8];