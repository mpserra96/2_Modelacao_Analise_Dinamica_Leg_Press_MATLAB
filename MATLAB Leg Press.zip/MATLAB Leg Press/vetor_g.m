% --------------------------------------------------------
% VETOR DAS FORÇAS GENERALIZADAS
% --------------------------------------------------------
g0 = 9.81;                 % aceleração gravítica

Fext = 900;                % força externa (N)
gvec = [ 0;
        -m1*g0;
         0;
         0;
        -m2*g0;
         0;
         Fext*cos(teta3);
        -m3*g0 + Fext*sin(teta3);
         0 ];
