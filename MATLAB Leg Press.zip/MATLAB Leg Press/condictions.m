% ------------------------------------------------------------
% INITIAL CONDITIONS (q0 e v0) - JUNTA DE TRANSLAÇÃO NA BARRA 3
% ------------------------------------------------------------

l1 = 0.39;   % m  (coxa)
l2 = 0.45;   % m  (perna-pe)
l3 = 0.70;   % m  (junta de translação)


xi = 0;
xj = 1;

yi = 1;
yj = 2;

% -------------------------
% GUIA NO CHÃO 
% -------------------------
xi = 0.0;  yi = 1.0;
xj = 1.0;  yj = 2.0;

dx = xj - xi;  dy = yj - yi;
L  = sqrt(dx^2 + dy^2);

ex = dx/L;  ey = dy/L;      % versor ao longo da guia (para cima)
nx = -ey;   ny =  ex;       % normal

teta1 = deg2rad(75);
teta2 = deg2rad(20);
teta3= deg2rad(45);


% --- Ponto 1 (centro da barra 1 / ou ponto de referência do elo 1)
x1 = 0.433*l1*cos(teta1);
y1 = 0.433*l1*sin(teta1);

% --- Ponto 2
x2 = x1 + 0.567*l1*cos(teta1) + 0.606*l2*cos(teta2);
y2 = y1 + 0.567*l1*sin(teta1) + 0.606*l2*sin(teta2);

% --- Ponto 3
x3 = x2 + 0.394*l2*cos(teta2)+ 0.5*l3*cos(teta3);
y3 = y2 + 0.394*l2*sin(teta2)+ 0.5*l3*sin(teta3);



q0 = [x1; y1; teta1
      x2; y2; teta2
      x3; y3; teta3]

v0 = zeros(9,1);
y  = [q0; v0];
