% -------------------------
% INTEGRAÇÃO (Euler)
% -------------------------
t = 0;
tfinal = 1;
h = 0.00005;

T = t:h:tfinal;
Y = zeros(18, length(T));
Y(:,1) = y;

k = 1;
pre_cputime = cputime;

while (k < length(T) && T(k) < tfinal)

    jacobian;

    vetor_g;
    vetor_gamma;


  % -------------------------
    % SISTEMA AUMENTADO
    % -------------------------
    MM  = [M, D';
           D, zeros(8)];

    rhs = [gvec; gamma];
    sol = MM \ rhs;

    % -------------------------
    % Euler
    % -------------------------
    y_dot = [y(10:18); sol(1:9)];
    y = y + h*y_dot;

    k = k + 1;
    Y(:,k) = y;
end

elapsed_time = cputime - pre_cputime;